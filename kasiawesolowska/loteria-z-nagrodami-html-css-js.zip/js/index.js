alert('To Twój szczęśliwy dzień. Weź udział w loterii i zgarnij kosmiczne nagrody!')
document.getElementById("demo").innerHTML =
Math.floor(Math.random() * 5);

function myFunction(name0) {
    document.getElementById("win0").innerHTML = name0;
}

function myFunction(name1) {
    document.getElementById("win1").innerHTML = name1;
}

function myFunction(name2) {
    document.getElementById("win2").innerHTML = name2;
}

function myFunction(name3) {
    document.getElementById("win3").innerHTML = "Wygrałaś... " + name3;
}

function myFunction(name4) {
    document.getElementById("win4").innerHTML = name4;
}